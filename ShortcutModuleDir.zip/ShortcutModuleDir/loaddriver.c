#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>


#define ROOT_UID    0
//command to insmod
#define INSMOD_PATH "/sbin/insmod"
//must change path on other cpus (to whereever you decided to store the module)
#define MOD_PATH    "/home/jamesmulvenna/ShortcutModuleDir/shortcutmodule.ko"

//system calls to run applications
void openBrowser(){
	int ret  = system("firefox http://www.google.com");
	if(ret == -1){
		printf("Failed.");
	}
}

void openEmail(){
	int ret = system("firefox http://www.outlook.com/ http://www.gmail.com");
	if(ret == -1){
		printf("Failed.");
	}
}

void openGalculator(){
	int ret = system("galculator");
	if(ret == -1){
		printf("Failed.");
	}
}

void openTerminal(){
	int ret = system("gnome-terminal");
	if(ret == -1){
		printf("Failed.");
	}
}

void openAudio(){
	int ret = system("spotify");
	if(ret == -1){
		printf("Failed.");
	}
}

void openSysPref(){
	int ret = system("unity-control-center");
	if(ret == -1){
		printf("Failed.");
	}
}

//cleanup call when remote program is ended (removes the module until the program is started up again)
void cleanUp(){
	//get rid of the module
	int ret = system("sudo rmmod shortcutmodule");
	//reattach internal devices
	int ret2 = system("xinput reattach 14 2");	
	int ret3 = system("xinput reattach 16 3");
	if(ret == -1 && ret2 == -1 && ret3 == -1){
		printf("Failed.");
	}
}

void userInputMenu(){
	int getASCII = 0;
	printf("\nWELCOME!\n");
	printf("Firefox Browser shortcut (i)\n");
	printf("Email shortcut (k)\n");
	printf("Galculator shortcut (j)\n");
	printf("New terminal shortcut (l)\n");
	printf("Spotify shortcut (w)\n");
	printf("System preferences (e)\n");
        printf("MACHINE POWER shortcut (q)\n");
	printf("Exit/ESC PROGRAM (z)\n\n");
	printf("With any of your choices press OK and then the mouse icon on the remote shall still function, if needed navigate to the search icon, search 'onboard' and open the application for a virtual keyboard.\n\n");
	printf("You will loose both your internal mouse, and keyboard. On ESC you'll gain them back.");
	printf("Please press the corresponding button of your choice: \n");
	printf("\n");

        //insmod usbhid for mouse functionality
	//remove internal mouse/keyboard done by xinput list and retrieving id, master#
	int ret = system("xinput float 14");
	int ret2 = system("xinput float 16");
	int ret3 = system("/sbin/modprobe usbhid");
	if(ret == -1 && ret2 == -1 && ret3 == -1){
		printf("Failed.");
	}

	while(1){
		
		getASCII = getchar();	
		
		//if up is pressed
		if(getASCII == 105){
			printf("Browser opened\n");
			openBrowser();
			userInputMenu();
			
		}
			
		//if down is pressed
		if(getASCII == 107){
			printf("E-mail opened\n");
			openEmail();
			userInputMenu();
			
		}
			
		//if left is pressed
		if(getASCII == 106){
			printf("Calculator opened\n");
			openGalculator();
			userInputMenu();
			
		}
		
		//if right is pressed	
		if(getASCII == 108){
			printf("Terminal opened\n");
			openTerminal();
			userInputMenu();
			
		}
		
		//if w is pressed 
		if(getASCII == 119){
			printf("Spotify opened\n");
			openAudio();
			userInputMenu();
		}

		//if e is pressed
		if(getASCII == 101){
			printf("System preferences opened\n");
			openSysPref();
			userInputMenu();
		}
		
		//if q is pressed
		if(getASCII == 113){
			printf("POWER OPTIONS");
		}

		//if esc is pressed
		if(getASCII == 122){
			printf("Okay, you have exited the remote functionality\n");
			printf("	1. CTRL + C to quit\n");
			printf("	2. Run sudo make to use the Remote again\n");
			printf("Other keyboard usb devices shall function at this time if you replug them in.\n");
			//remove the module
			cleanUp();
		}
			
	}


}



int main(void)
{
    //get the userid
    uid_t uid;
    int res;

    //program being run by root userid
    uid = getuid();

    if (uid != ROOT_UID) {
	//not root
        fprintf(stderr, "Error: Please run this program as root\n");
        return EXIT_FAILURE;
    }

    if (access(MOD_PATH, F_OK) == -1) {
	//if its already inserted run the program anyways
        fprintf(stderr, "Error: File \"%s\" doesn't exist\n", MOD_PATH);
        userInputMenu();
    }

    res = system(INSMOD_PATH " " MOD_PATH);
    if (res != 0) {
        fprintf(stderr, "Error loading module: %d\n", res);
        userInputMenu();
    }

    
    //if its not inserted, insert the module, and run userInputMenu();
    printf("Module \"%s\" was successfully loaded\n", MOD_PATH);
    userInputMenu();


    return EXIT_SUCCESS;
}


