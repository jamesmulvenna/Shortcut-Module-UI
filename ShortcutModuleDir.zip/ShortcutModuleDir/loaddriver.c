#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

#define ROOT_UID    0
#define INSMOD_PATH "/sbin/insmod"
#define MOD_PATH    "/home/jamesmulvenna/ShortcutModuleDir/shortcutmodule.ko"

void openBrowser(){
	system("firefox http://www.google.com");
}

void openEmail(){
	system("firefox http://www.outlook.com/ http://www.gmail.com");
}

void openGalculator(){
	system("galculator");
}

void openTerminal(){
	system("gnome-terminal");
}

void openAudio(){
	system("spotify");
}

void openSysPref(){
	system("unity-control-center");
}

void cleanUp(){
	system("sudo rmmod shortcutmodule");
}

void userInputMenu(){
	int getASCII = 0;
	printf("\nWELCOME!\n");
	printf("Firefox Browser shortcut\n");
	printf("Email shortcut\n");
	printf("Galculator shortcut\n");
	printf("New terminal shortcut\n");
	printf("Spotify shortcut\n");
	printf("System preferences\n");
        printf("MACHINE POWER shortcut\n");
	printf("Exit/ESC PROGRAM\n\n");
	printf("With any of your choices the mouse icon on the remote shall still function, if needed navigate to the search icon, search 'onboard' and open the application for a virtual keyboard.\n\n");
	printf("Please press the corresponding button of your choice: \n");
	printf("\n");

  
	system("/sbin/modprobe usbhid");

	while(1){
		
		getASCII = getchar();	
		
		//up
		if(getASCII == 105){
			printf("Browser opened\n");
			openBrowser();
			userInputMenu();
			
		}
			
		//down
		if(getASCII == 107){
			printf("E-mail opened\n");
			openEmail();
			userInputMenu();
			
		}
			
		//left
		if(getASCII == 106){
			printf("Calculator opened\n");
			openGalculator();
			userInputMenu();
			
		}
		
		//right	
		if(getASCII == 108){
			printf("Terminal opened\n");
			openTerminal();
			userInputMenu();
			
		}
		
		//w
		if(getASCII == 119){
			printf("Spotify opened\n");
			openAudio();
			userInputMenu();
		}

		//e
		if(getASCII == 101){
			printf("System preferences opened\n");
			openSysPref();
			userInputMenu();
		}
		
		//q
		if(getASCII == 113){
			printf("POWER OPTIONS");
		}

		if(getASCII == 114){
			printf("Okay, you have exited the remote functionality\n");
			printf("	1. CTRL + C to quit\n");
			printf("	2. Run sudo make to use the Remote again\n");
			printf("Other usb devices shall work at this time.\n");
			cleanUp();
		}
			
	}


}



int main(void)
{
    uid_t uid;
    int res;

    /* Check if program being run by root */
    uid = getuid();
    if (uid != ROOT_UID) {
        fprintf(stderr, "Error: Please run this program as root\n");
        return EXIT_FAILURE;
    }

    /* Check if module file exists */
    if (access(MOD_PATH, F_OK) == -1) {
        fprintf(stderr, "Error: File \"%s\" doesn't exist\n", MOD_PATH);
        userInputMenu();
    }

    /* Load module */
    res = system(INSMOD_PATH " " MOD_PATH);
    if (res != 0) {
        fprintf(stderr, "Error loading module: %d\n", res);
        userInputMenu();
    }

    

    //printf("Module \"%s\" was successfully loaded\n", MOD_PATH);
    userInputMenu();



    return EXIT_SUCCESS;
}


