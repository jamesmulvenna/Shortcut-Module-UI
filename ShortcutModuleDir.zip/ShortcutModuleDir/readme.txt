HID Computer Remote with Convenient Shortcut User Interface

Short readme for opensource code

*Works on VERSION 16.04*

By this point you've downloaded the source code from https://github.com/jamesmulvenna/Shortcut-Module-UI/upload/master

First and for most this remote paired with the driver + UI provides a convenient option for CPU
users who aren't always sitting infront of their machines, or tend to use externel displays.

For instance plugging CPU into television and watching "Netflix" from bed.

The steps to getting started are:

0. MUST HAVE MYGICA REMOTE FOR THIS TO WORK, it also utilizes the following programs:
	- Default linux browser (Firefox)
	- Galculator
	- Default linux terminal
	- Spotify

***MUST BE ROOT (SUDO ACCESS) USER TO RUN PROGRAM***

1. Place the ShortcutModuleDir directory whereever however you must change the MODPATH in loaddriver.c (located at the top of the file)
2. Cd into ShortcutModuleDir
3. Simply type sudo make clean to make sure the program is in ready state
4. Type sudo make
5. You will see the module being compiled and inserted into the kernel space
6. The UI will also come up with a list of your options, you will see corresponding pictures on the device with respect to the options
7. The UI provides a nice layout that is friendly and helps you along the way however if you choose to esc the program, the device will no longer work (only lasts for life of process)
8. Running sudo make will register the device once again, and you will be back to using the convenient remote
9. Thats basically it, trial and error will help you learn the functionality best
