#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/usb/input.h>
#include <linux/hid.h>
#include <linux/kmod.h>
#include <linux/usb/hcd.h>


/*Module information
--------------------*/

#define DRIVER_AUTHOR "James Mulvenna & Jori Saikali "
#define DRIVER_DESC "USB Shortcut remote driver"
#define DRIVER_LICENSE "GPL"

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE(DRIVER_LICENSE);

//map of keycode for universal keyboards on linux
static const unsigned char usb_kbd_keycode[256] = {
	  0,  0,  0,  0, 30, 48, 46, 32, 18, 33, 34, 35, 0, 0, 0, 0,
	 50, 49, 24, 25, 116, 19, 31, 20, 22, 47, 17, 45, 21, 44,  2,  3,
	  4,  5,  6,  7,  8,  9, 10, 11, 28,  1, 14, 15, 57, 12, 13, 26,
	 27, 43, 43, 39, 40, 41, 51, 52, 53, 58, 59, 60, 61, 62, 63, 64,
	 65, 66, 67, 68, 87, 88, 99, 70,119,110,102,104,111,107,109,38,
	36,37,23, 69, 98, 55, 74, 78, 96, 79, 80, 81, 75, 76, 77, 71,
	 72, 73, 82, 83, 86,127,116,117,183,184,185,186,187,188,189,190,
	191,192,193,194,134,138,130,132,128,129,131,137,133,135,136,113,
	115,114,  0,  0,  0,121,  0, 89, 93,124, 92, 94, 95,  0,  0,  0,
	122,123, 90, 91, 85,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	 29, 42, 56,125, 97, 54,100,126,164,166,165,163,161,115,114,113,
	150,158,159,128,136,177,178,176,142,152,173,140
};

//keyboard state
struct usb_kbd {
	struct input_dev *gicadev; //device associated with the keyboard
	struct usb_device *usbdev; //usb device associated with the device
	unsigned char old[8]; //old keys pressed
	struct urb *irq; //register press/release
	char name[128]; //name of keyboard
	char phys[64]; //keyboard path

	unsigned char *new; //buffer
	struct usb_ctrlrequest *cr; //control req for URB
	dma_addr_t new_dma; //adress for URB
};


//function registers keypress/release, this is where we determine if the keys we're interested in are pressed
static void usb_kbd_irq(struct urb *gicaurb)
{
	struct usb_kbd *gicakbd = gicaurb->context;
	int i;
	
	
	//check status of keyboard for errors
	switch (gicaurb->status) {
	case 0:			/* success */
		break;
	case -ECONNRESET:	/* unlink */
	case -ENOENT:
	case -ESHUTDOWN:
		return;
	/* -EPIPE:  should clear the halt */
	default:		/* error */
		goto resubmit;
	}

	//report all keycodes 
	for (i = 0; i < 8; i++)
		input_report_key(gicakbd->gicadev, usb_kbd_keycode[i + 224], (gicakbd->new[0] >> i) & 1);

	for (i = 2; i < 8; i++) {
		//scan for proper/improper keycodes
		if (gicakbd->old[i] > 3 && memscan(gicakbd->new + 2, gicakbd->old[i], 6) == gicakbd->new + 8) {
			if (usb_kbd_keycode[gicakbd->old[i]])
				//report known keys released
				input_report_key(gicakbd->gicadev, usb_kbd_keycode[gicakbd->old[i]], 0);
			else
				hid_info(gicaurb->dev,
					 "Unknown key (scancode %#x) released.\n",
					 gicakbd->old[i]);
		}

		if (gicakbd->new[i] > 3 && memscan(gicakbd->old + 2, gicakbd->new[i], 6) == gicakbd->old + 8) {
			if (usb_kbd_keycode[gicakbd->new[i]]){
				//report known keys pressed
				input_report_key(gicakbd->gicadev, usb_kbd_keycode[gicakbd->new[i]], 1);
			}
			else{
				hid_info(gicaurb->dev,
					 "Unknown key (scancode %#x) pressed.\n",
					 gicakbd->new[i]);
			}
		}
	}

	i = 0;

	for (i = 2; i < 8; i++){

		//loop over keycodes again determining if specific codes were pressed, print to the kernel information
		if (gicakbd->new[i] > 3 && memscan(gicakbd->old + 2, gicakbd->new[i], 6) == gicakbd->old + 8) {
			if (usb_kbd_keycode[gicakbd->new[i]] == 23){
				printk(KERN_INFO "[*] UP_KEY, browser\n");
			}
			if (usb_kbd_keycode[gicakbd->new[i]] == 37){
				printk(KERN_INFO "[*] DOWN_KEY, email\n");
			}
			if (usb_kbd_keycode[gicakbd->new[i]] == 38){
				printk(KERN_INFO "[*] RIGHT_KEY, terminal\n");
			}
			if (usb_kbd_keycode[gicakbd->new[i]] == 36){
				printk(KERN_INFO "[*] LEFT_KEY, calculator\n");
			}
			if (usb_kbd_keycode[gicakbd->new[i]] == 17){
				printk(KERN_INFO "[*] W key, spotify\n");
			}
			if (usb_kbd_keycode[gicakbd->new[i]] == 18){
				printk(KERN_INFO "[*] E key, system preferences\n");
			}
			if (usb_kbd_keycode[gicakbd->new[i]] == 19){
				printk(KERN_INFO "[*] R key, esc\n");
			}
			if (usb_kbd_keycode[gicakbd->new[i]] == 116){
				printk(KERN_INFO "[*] Power key, shutdown\n");
			}
	}
}

	//sync the keyboard
	input_sync(gicakbd->gicadev);

	memcpy(gicakbd->old, gicakbd->new, 8);

//callback for urb req
resubmit:
	i = usb_submit_urb (gicaurb, GFP_ATOMIC);
	if (i)
		hid_err(gicaurb->dev, "can't resubmit intr, %s-%s/input0, status %d",
			gicakbd->usbdev->bus->bus_name,
			gicakbd->usbdev->devpath, i);
}

//keyboard gets data from device
static int usb_kbd_open(struct input_dev *thisdev)
{
	struct usb_kbd *gicakbd = input_get_drvdata(thisdev);

	//obtain device information
	gicakbd->irq->dev = gicakbd->usbdev;
	if (usb_submit_urb(gicakbd->irq, GFP_KERNEL))
		return -EIO;

	return 0;
}

//keyboard gets data from device and closes
static void usb_kbd_close(struct input_dev *thisdev)
{
	//obtain device information
	struct usb_kbd *gicakbd = input_get_drvdata(thisdev);

	//kill the keyboard
	usb_kill_urb(gicakbd->irq);
}

//alloc memory for device, using new_dma address
static int usb_kbd_alloc_mem(struct usb_device *thisdev, struct usb_kbd *gicakbd)
{
	if (!(gicakbd->irq = usb_alloc_urb(0, GFP_KERNEL)))
		return -1;
	if (!(gicakbd->new = usb_alloc_coherent(thisdev, 8, GFP_ATOMIC, &gicakbd->new_dma)))
		return -1;
	if (!(gicakbd->cr = kmalloc(sizeof(struct usb_ctrlrequest), GFP_KERNEL)))
		return -1;

	//return 0 on success
	return 0;
}

//free memory for device on close, using new_dma address referenced
static void usb_kbd_free_mem(struct usb_device *thisdev, struct usb_kbd *gicakbd)
{
	usb_free_urb(gicakbd->irq);
	usb_free_coherent(thisdev, 8, gicakbd->new, gicakbd->new_dma);
	kfree(gicakbd->cr);
}

//Probe is one of the major functions of this driver, it takes the functions implemented above along with device information to initialize the driver
static int usb_kbd_probe(struct usb_interface *iface,
			 const struct usb_device_id *id)
{
	//MUST COMMENT AND MAKE MY OWN
	struct usb_device *dev = interface_to_usbdev(iface);
	struct usb_host_interface *interface;
	struct usb_endpoint_descriptor *endpoint;
	struct usb_kbd *kbd;
	struct input_dev *input_dev;
	int i, pipe, maxp;
	int error = -ENOMEM;

	interface = iface->cur_altsetting;

	if (interface->desc.bNumEndpoints != 1)
		return -ENODEV;

	endpoint = &interface->endpoint[0].desc;
	if (!usb_endpoint_is_int_in(endpoint))
		return -ENODEV;

	pipe = usb_rcvintpipe(dev, endpoint->bEndpointAddress);
	maxp = usb_maxpacket(dev, pipe, usb_pipeout(pipe));

	kbd = kzalloc(sizeof(struct usb_kbd), GFP_KERNEL);
	input_dev = input_allocate_device();
	if (!kbd || !input_dev)
		goto fail1;

	if (usb_kbd_alloc_mem(dev, kbd))
		goto fail2;

	kbd->usbdev = dev;
	kbd->gicadev = input_dev;

	if (dev->manufacturer)
		strlcpy(kbd->name, dev->manufacturer, sizeof(kbd->name));

	if (dev->product) {
		if (dev->manufacturer)
			strlcat(kbd->name, " ", sizeof(kbd->name));
		strlcat(kbd->name, dev->product, sizeof(kbd->name));
	}

	if (!strlen(kbd->name))
		snprintf(kbd->name, sizeof(kbd->name),
			 "MYGICA Remote %04x:%04x",
			 le16_to_cpu(dev->descriptor.idVendor),
			 le16_to_cpu(dev->descriptor.idProduct));

	usb_make_path(dev, kbd->phys, sizeof(kbd->phys));
	strlcat(kbd->phys, "/input0", sizeof(kbd->phys));

	input_dev->name = kbd->name;
	input_dev->phys = kbd->phys;
	usb_to_input_id(dev, &input_dev->id);
	input_dev->dev.parent = &iface->dev;

	input_set_drvdata(input_dev, kbd);

	input_dev->evbit[0] = BIT_MASK(EV_KEY) | BIT_MASK(EV_LED) |
		BIT_MASK(EV_REP);
	input_dev->ledbit[0] = BIT_MASK(LED_NUML) | BIT_MASK(LED_CAPSL) |
		BIT_MASK(LED_SCROLLL) | BIT_MASK(LED_COMPOSE) |
		BIT_MASK(LED_KANA);

	for (i = 0; i < 255; i++){
		set_bit(usb_kbd_keycode[i], input_dev->keybit);
	}


	input_dev->open = usb_kbd_open;
	input_dev->close = usb_kbd_close;

	usb_fill_int_urb(kbd->irq, dev, pipe,
			 kbd->new, (maxp > 8 ? 8 : maxp),
			 usb_kbd_irq, kbd, endpoint->bInterval);
	kbd->irq->transfer_dma = kbd->new_dma;
	kbd->irq->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;

	kbd->cr->bRequestType = USB_TYPE_CLASS | USB_RECIP_INTERFACE;
	kbd->cr->bRequest = 0x09;
	kbd->cr->wValue = cpu_to_le16(0x200);
	kbd->cr->wIndex = cpu_to_le16(interface->desc.bInterfaceNumber);
	kbd->cr->wLength = cpu_to_le16(1);

	error = input_register_device(kbd->gicadev);
	if (error)
		goto fail2;

	usb_set_intfdata(iface, kbd);
	device_set_wakeup_enable(&dev->dev, 1);
	return 0;

fail2:	
	usb_kbd_free_mem(dev, kbd);
fail1:	
	input_free_device(input_dev);
	kfree(kbd);
	return error;
}

static void usb_kbd_disconnect(struct usb_interface *gicaface)
{
	struct usb_kbd *gicakbd = usb_get_intfdata (gicaface);

	usb_set_intfdata(gicaface, NULL);
	if (gicakbd) {
		usb_kill_urb(gicakbd->irq);
		input_unregister_device(gicakbd->gicadev);
		usb_kbd_free_mem(interface_to_usbdev(gicaface), gicakbd);
		kfree(gicakbd);
		printk(KERN_INFO "[*] MYGICA Remote driver removed\n");
	}
}

static struct usb_device_id remote_table[] = {
	{ USB_INTERFACE_INFO(USB_INTERFACE_CLASS_HID, USB_INTERFACE_SUBCLASS_BOOT,
		USB_INTERFACE_PROTOCOL_KEYBOARD) },
	{}
};

MODULE_DEVICE_TABLE (usb, remote_table);

static struct usb_driver remote_driver = 
{
	.name = "MyGica-USB Remote-Driver",
	.id_table = remote_table,
	.probe = usb_kbd_probe,
	.disconnect = usb_kbd_disconnect,
};

module_usb_driver(remote_driver);

