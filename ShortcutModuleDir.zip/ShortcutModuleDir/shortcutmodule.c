#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/usb/input.h>
#include <linux/hid.h>
#include <linux/kmod.h>
#include <linux/usb/hcd.h>

/*Module information
--------------------*/

#define DRIVER_AUTHOR "James Mulvenna & Jori Saikali "
#define DRIVER_DESC "USB Shortcut remote driver"
#define DRIVER_LICENSE "GPL"

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE(DRIVER_LICENSE);

//map of keycode for universal keyboards on linux
// only onboard qwer ijkl volup voldown stop back < play/pause > mouse work
// the rest don't work as this is what our objective was
static const unsigned char usb_kbd_keycode[256] = {
	  0,  0,  0,  0, 30, 48, 0, 32, 18, 0, 0, 0, 0, 0, 0, 0,
	 0, 49, 0, 0, 116, 19, 0, 0, 0, 0, 17, 0, 0, 44,  0,  0,
	  0,  0,  0,  0,  0,  0, 0, 0, 28,  1, 14, 0	, 0, 0, 0, 26,
	 27, 0, 0, 0, 0, 41, 0, 0, 0, 0, 59, 60, 61, 62, 63, 64,
	 65, 66, 67, 68, 87, 88, 99, 70,119,110,102,104,111,107,109,38,
	36,37,23, 69, 98, 55, 74, 78, 96, 79, 80, 81, 75, 76, 77, 71,
	 72, 73, 82, 83, 86,0,116,117,183,184,185,186,187,188,189,190,
	191,192,193,194,134,138,130,132,128,129,131,137,133,135,136,113,
	115,114,  0,  0,  0,121,  0, 89, 93,124, 92, 94, 95,  0,  0,  0,
	122,123, 90, 91, 85,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	 29, 0, 56,125, 97, 54,100,126,164,0,165,163,161,115,114,113,
	150,158,159,128,136,177,178,176,142,152,173,140
};

/* 
USB - Universal serial bus 
DEV - device
IRQ - interrupt request line
DMA - Direct memory access (ram)
CTRL cr - Control Request Change Request



*/

//keyboard state
struct usb_kbd {
	struct input_dev *gicadev; //device associated with the keyboard
	struct usb_device *usbdev; //usb device associated with the device
	unsigned char oldkeys[8]; //old keys pressed
	struct urb *irq; //register press/release (interrupt request line deals with hardware sending signals to the processor)
	char name[128]; //name of keyboard
	char path[64]; //keyboard path

	unsigned char *newkeys; //buffer for new keys
	struct usb_ctrlrequest *cr; //control req for URB
	dma_addr_t new_dma; //adress for URB (storing keyboard)
};


//function registers keypress/release, this is where we determine if the keys we're interested in are pressed
static void gica_kbd_irq(struct urb *gicaurb)
{
	struct usb_kbd *gicakbd = gicaurb->context;
	int i;
	
	
	//check status of keyboard for errors
	switch (gicaurb->status) {
	case 0:			// success, passed link keyboard
		break;
	case -ECONNRESET:	// don't link keyboard
	case -ENOENT:
	case -ESHUTDOWN:
		return;
	default:		//on error go to resubmit
		goto resubmit;
	}

	//report all keycodes registered keycodes
	//loops 8 increments because theres 8 bits/key
	for (i = 0; i < 8; i++)
		input_report_key(gicakbd->gicadev, usb_kbd_keycode[i + 224], (gicakbd->newkeys[0] >> i) & 1);

	for (i = 2; i < 8; i++) {
		//scan for proper/improper keycodes released
		if (gicakbd->oldkeys[i] > 3 && memscan(gicakbd->newkeys + 2, gicakbd->oldkeys[i], 6) == gicakbd->newkeys + 8) {
			if (usb_kbd_keycode[gicakbd->oldkeys[i]])
				//report known keys released
				input_report_key(gicakbd->gicadev, usb_kbd_keycode[gicakbd->oldkeys[i]], 0);
			else
				hid_info(gicaurb->dev,
					 "Unknown key (scancode %#x) released.\n",
					 gicakbd->oldkeys[i]);
		}
		
		//scan for proper/improper keycodes pressed
		if (gicakbd->newkeys[i] > 3 && memscan(gicakbd->oldkeys + 2, gicakbd->newkeys[i], 6) == gicakbd->oldkeys + 8) {
			if (usb_kbd_keycode[gicakbd->newkeys[i]]){
				//report known keys pressed
				input_report_key(gicakbd->gicadev, usb_kbd_keycode[gicakbd->newkeys[i]], 1);
			}
			else{
				hid_info(gicaurb->dev,
					 "Unknown key (scancode %#x) pressed.\n",
					 gicakbd->newkeys[i]);
			}
		}
	}

	//reset i and check for specific keycodes
	i = 0;

	for (i = 0; i < 8; i++){

		//loop over keycodes again determining if specific codes were pressed, print to the kernel information
		if (gicakbd->newkeys[i] > 3 && memscan(gicakbd->oldkeys + 2, gicakbd->newkeys[i], 6) == gicakbd->oldkeys + 8) {
			//key for browser
			if (usb_kbd_keycode[gicakbd->newkeys[i]] == 23){
				printk(KERN_INFO "[*] UP_KEY, browser\n");
			}
			//key for email
			if (usb_kbd_keycode[gicakbd->newkeys[i]] == 37){
				printk(KERN_INFO "[*] DOWN_KEY, email\n");
			}
			//key for terminal
			if (usb_kbd_keycode[gicakbd->newkeys[i]] == 38){
				printk(KERN_INFO "[*] RIGHT_KEY, terminal\n");
			}
			//key for calculator
			if (usb_kbd_keycode[gicakbd->newkeys[i]] == 36){
				printk(KERN_INFO "[*] LEFT_KEY, calculator\n");
			}
			//key for spotify
			if (usb_kbd_keycode[gicakbd->newkeys[i]] == 17){
				printk(KERN_INFO "[*] W key, spotify\n");
			}
			//key for system preferences
			if (usb_kbd_keycode[gicakbd->newkeys[i]] == 18){
				printk(KERN_INFO "[*] E key, system preferences\n");
			}
			//key for esc
			if (usb_kbd_keycode[gicakbd->newkeys[i]] == 44){
				printk(KERN_INFO "[*] Z key, esc\n");
			}
			//key for shutdown
			if (usb_kbd_keycode[gicakbd->newkeys[i]] == 116){
				printk(KERN_INFO "[*] Power key, shutdown\n");
			}
	}
}

	//sync the keyboard to the system
	input_sync(gicakbd->gicadev);

	memcpy(gicakbd->oldkeys, gicakbd->newkeys, 8);

//callback for urb req error
resubmit:
	i = usb_submit_urb (gicaurb, GFP_ATOMIC);
	if (i)
		hid_err(gicaurb->dev, "can't resubmit intr, %s-%s/input0, status %d",
			gicakbd->usbdev->bus->bus_name,
			gicakbd->usbdev->devpath, i);
}

//keyboard gets data from device
static int gica_kbd_open(struct input_dev *thisdev)
{
	struct usb_kbd *gicakbd = input_get_drvdata(thisdev);

	//obtain device information
	gicakbd->irq->dev = gicakbd->usbdev;
	if (usb_submit_urb(gicakbd->irq, GFP_KERNEL))
		return -EIO;

	//success
	return 0;
}

//keyboard gets data from device and closes
static void gica_kbd_close(struct input_dev *thisdev)
{
	//obtain device information
	struct usb_kbd *gicakbd = input_get_drvdata(thisdev);

	//kill the keyboard request
	usb_kill_urb(gicakbd->irq);
}

//allocate memory for device, using new_dma address
static int gica_kbd_alloc_mem(struct usb_device *thisdev, struct usb_kbd *gicakbd)
{
	//if the irq fails to allocate or if the keyboards new keys fail to allocate
	//or if the ctrl req fails to allocate
	if (!(gicakbd->irq = usb_alloc_urb(0, GFP_KERNEL)) || 
	    !(gicakbd->newkeys = usb_alloc_coherent(thisdev, 8, GFP_ATOMIC, &gicakbd->new_dma)) || 
	    !(gicakbd->cr = kmalloc(sizeof(struct usb_ctrlrequest), GFP_KERNEL)))
		return -1;

	//return 0 on success
	return 0;
}

//free memory for device on close, using new_dma address referenced
static void gica_kbd_free_mem(struct usb_device *thisdev, struct usb_kbd *gicakbd)
{
	//essentially clear what we previously allocated
	//free irq req, new keys, and the ctrl request
	usb_free_urb(gicakbd->irq);
	usb_free_coherent(thisdev, 8, gicakbd->newkeys, gicakbd->new_dma);
	kfree(gicakbd->cr);
}

static void transferCrDMA(struct usb_kbd *gicakbd){
	//change memory (transfer the irq direct memory access to the new dma (computer ram))
	gicakbd->irq->transfer_dma = gicakbd->new_dma;
	
	gicakbd->irq->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;

	gicakbd->cr->bRequestType = USB_TYPE_CLASS | USB_RECIP_INTERFACE;
	gicakbd->cr->bRequest = 0x09;
	gicakbd->cr->wValue = cpu_to_le16(0x200);
	gicakbd->cr->wLength = cpu_to_le16(1);
}

static void getInfo(struct usb_device *dev, struct usb_kbd *gicakbd){

	if (dev->manufacturer)
		strlcpy(gicakbd->name, dev->manufacturer, sizeof(gicakbd->name));

	if (dev->product) {
		if (dev->manufacturer)
			strlcat(gicakbd->name, " ", sizeof(gicakbd->name));
		strlcat(gicakbd->name, dev->product, sizeof(gicakbd->name));
	}

	
	if (!strlen(gicakbd->name))
		snprintf(gicakbd->name, sizeof(gicakbd->name),
			 "MYGICA Remote id's %04x:%04x",
			//printing remotes id (Vendor/Product)
			 le16_to_cpu(dev->descriptor.idVendor),
			 le16_to_cpu(dev->descriptor.idProduct));
}

//Probe is one of the most important functions of this driver, it takes the functions implemented above along with device information to create the driver (critical part of the module)
static int remote_kbd_probe(struct usb_interface *gicainterface, const struct usb_device_id *id)
{
	// set the device to the gica interface
	struct usb_device *dev = interface_to_usbdev(gicainterface);
	//kernel interface
	struct usb_host_interface *interface;
	//transfer point
	struct usb_endpoint_descriptor *endpoint;
	//this keyboard
	struct usb_kbd *gicakbd;
	//device
	struct input_dev *input_dev;
	//max packets/pipe
	int i;
	int pipe;
	int maxp;
	//error variable
	int error = -ENOMEM;

	//set the interface to this interface
	interface = gicainterface->cur_altsetting;

	/*needs an end point for transfer ( essentially setting up for transfer of data so the os 
	knows who MYGICA is and what to do with it*/

	if (interface->desc.bNumEndpoints != 1)
		return -ENODEV;

	endpoint = &interface->endpoint[0].desc;
	if (!usb_endpoint_is_int_in(endpoint))
		return -ENODEV;

	//data transfer of max packets through the pipe
	pipe = usb_rcvintpipe(dev, endpoint->bEndpointAddress);
	maxp = usb_maxpacket(dev, pipe, usb_pipeout(pipe));

	//sent data now we allocate kernel memory for the keyboard
	gicakbd = kzalloc(sizeof(struct usb_kbd), GFP_KERNEL);
	//allocate kernel memory for the device
	input_dev = input_allocate_device();
	//didn't allocate
	if (!gicakbd)
		//free keyboard
		goto freedev;
	if(!input_dev)
		goto freedev;

	if (gica_kbd_alloc_mem(dev, gicakbd))
		//free memory
		goto freemem;

	//set kbd usb and dev
	gicakbd->usbdev = dev;
	gicakbd->gicadev = input_dev;

	// weve allocated for both the keyboard and device now we need to gain information about the 		   keyboard/device (manufacturer, product)
	getInfo(dev, gicakbd);
	

	//make a path for the keyboard path (size of keyboard)
	usb_make_path(dev, gicakbd->path, sizeof(gicakbd->path));
	strlcat(gicakbd->path, "/input0", sizeof(gicakbd->path));

	//transfer of relevant data (name, path)
	input_dev->name = gicakbd->name;
	input_dev->phys = gicakbd->path;
	
	//transfer of id, and assignment of dev.parent
	usb_to_input_id(dev, &input_dev->id);
	input_dev->dev.parent = &gicainterface->dev;
	
	
	input_set_drvdata(input_dev, gicakbd);
	
	input_dev->evbit[0] = BIT_MASK(EV_KEY) | BIT_MASK(EV_REP);


	//assign keycodes to default keyboard
	for (i = 0; i < 255; i++){
		set_bit(usb_kbd_keycode[i], input_dev->keybit);
	}
	clear_bit(0, input_dev->keybit);

	//assign callbacks for open and close (callbacks made earlier in the program)
	input_dev->open = gica_kbd_open;
	input_dev->close = gica_kbd_close;

	
	usb_fill_int_urb(gicakbd->irq, dev, pipe,
			 gicakbd->newkeys, (maxp > 8 ? 8 : maxp),
			gica_kbd_irq , gicakbd, endpoint->bInterval);

	transferCrDMA(gicakbd);
	gicakbd->cr->wIndex = cpu_to_le16(interface->desc.bInterfaceNumber);
	

	//if return value (error) is true from registering the new device then fail
	error = input_register_device(gicakbd->gicadev);
	if (error)
		//free memory
		goto freemem;

	//set the interface data, and enable the device
	usb_set_intfdata(gicainterface, gicakbd);
	device_set_wakeup_enable(&dev->dev, 1);
	//success
	return 0;

freemem:	
	gica_kbd_free_mem(dev, gicakbd);
freedev:	
	input_free_device(input_dev);
	kfree(gicakbd);
	return error;
}

//disconnecting the keyboard interface
static void remote_kbd_disconnect(struct usb_interface *gicaface)
{
	//obtain total interface data
	struct usb_kbd *gicakbd = usb_get_intfdata (gicaface);

	//set the data to null
	usb_set_intfdata(gicaface, NULL);
	//if the keyboard is avaliable, kill urb req, unregister the device, free the memory and keyboard, and finally print to dmesg notifying the device has been removed
	if (gicakbd) {
		usb_kill_urb(gicakbd->irq);
		input_unregister_device(gicakbd->gicadev);
		gica_kbd_free_mem(interface_to_usbdev(gicaface), gicakbd);
		kfree(gicakbd);
		printk(KERN_ALERT "[*] MYGICA Remote driver has been removed\n");
	}
}

//remote id including vendor id product id, and other useful information to register the device
static struct usb_device_id remote_table[] = {
	{ USB_INTERFACE_INFO(USB_INTERFACE_CLASS_HID, USB_INTERFACE_SUBCLASS_BOOT,
		USB_INTERFACE_PROTOCOL_KEYBOARD) },
	{} // Terminate the device id
};

//expose vendor and product ids at compile time kernel gathers this information
MODULE_DEVICE_TABLE (usb, remote_table);

//declare variables to be used (critical part of this module driver)
static struct usb_driver remote_driver = 
{
	.name = "MyGica-USB Remote-Driver",
	.id_table = remote_table,
	.probe = remote_kbd_probe,
	.disconnect = remote_kbd_disconnect,
};

//register driver
module_usb_driver(remote_driver);



/* REFERENCE/CREDIT TO Linux USBKBD.c, lots of functionality and logic based off this module and its sources*/

